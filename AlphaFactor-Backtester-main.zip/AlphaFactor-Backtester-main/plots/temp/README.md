### This directory stores outputs of backtests, named by timestamps.

- BacktestSetting.json
- results.h5
- full_tearsheet.html
