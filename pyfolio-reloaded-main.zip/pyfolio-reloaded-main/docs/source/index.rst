.. title:: pyfolio

.. mdinclude:: ../../README.md

.. toctree::
   :maxdepth: 4

   notebooks/single_stock_example
   notebooks/zipline_algo_example
   notebooks/round_trip_tear_sheet_example
   notebooks/sector_mappings_example
   api-reference
